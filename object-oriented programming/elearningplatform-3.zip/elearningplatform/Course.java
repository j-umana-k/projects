package elearningplatform;

/* Name : reem ALshahrani
Id: 445000375
group : 2
*/


 import java.util.ArrayList;
import java.util.List;
/* 
 * The Course class represents an educational course in an e-learning platform.
 * It contains: courseId ,courseName, professor ,students ,duration
 *
 *  The Main functions is 
 * 1. Create a course with or without parameters.
 * 2. Add or remove students from the course.
 * 3. Retrieve course details.
 * 4. Getters and setters for properties.
 *
 * The class overrides toString and equals
 */
public class Course {
    private int courseId;
    private String courseName;
    private Professor professor;
    private List<Student> students;
    private String duration; // مدة الدورة

    public Course(){
    }
    
     /**
      Parameterized constructor to initialize course details.
      
      @param courseId   Unique identifier for the course.
      @param courseName Name of the course.
      @param professor  Professor teaching the course.
      @param duration   Duration of the course.
     */
    
    public Course(int courseId, String courseName, Professor professor, String duration) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.professor = professor;
        this.students = new ArrayList<>();
        this.duration = duration;
    }
/**
      Adds a student to the course.
      @param student The student that will be added.
     */
   
    public void addStudent(Student student) {
        try {
            students.add(student);
            System.out.println("Student added successfully.");
        } catch (Exception e) {
            System.out.println("Error while adding student: " + e.getMessage());
        }
    }

    /**
      Removes a student from the course.
      @param student The student to be removed.
     */
    public void removeStudent(Student student) {
        try {
            if (students.contains(student)) {
                students.remove(student);
                System.out.println("Student removed successfully.");
            } else {
                System.out.println("Student not found in the course.");
            }
        } catch (Exception e) {
            System.out.println("Error while removing student: " + e.getMessage());}}
    // Details
    public String getCourseDetails() {
        return "Course Name: " + courseName + 
               ", Professor: " + professor.getName() + 
               ", Duration: " + duration;
    }
  // Override toString method
    @Override
    public String toString() {
        return "Course ID: " + courseId + 
               ", Name: " + courseName + 
               ", Professor: " + professor.getName();
    }

    // Override equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Course course = (Course) obj;
        return courseId == course.courseId &&
               courseName.equals(course.courseName) &&
               professor.equals(course.professor);
    }

    // Getters and Setters
    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}