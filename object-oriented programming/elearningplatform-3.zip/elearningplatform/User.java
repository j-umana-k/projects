package elearningplatform;
/**
 * The User class represents a general information about users. 
 * It provides constructors to create a user and methods to get and set user details. 
 * This class is abstract and includes an abstract method to display user information 
 * and interface methods for user login and logout.

 * name : Jumana khalid Alsaedi
 * ID : 445007196
 * group : 2
 * @author Jumana khalid Alsaedi
*/

public abstract class User implements UserInterface {
    
    /*The name of the user*/
    private String name;
    
    /*The email of the user*/
    private String email;
    
    /*The password of the user*/
    private String password;
    
       
    /* Default Constructors
    * initializes the user with default values
    */

    public User() {
    this.name = " ";
    this.email = " ";
    this.password = " ";
    System.out.print("Error : No information has been entered , default values have been set");    
    }
   
   
   /*Constructor with name, email, and password parameters.
     * @param name the name of the user
     * @param email the email of the user
     *@param password the password of the user
    */
    
    public User( String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    /*Setters and Getters
     *
     *Gets the name of the user
     *@return the name of the user
    */
    
    public String getName() {
        return name;
    }

    /*
     * Sets the name of the user
     *
     * @param name the name to set
     * @throws IllegalArgumentException if the name is null 
    */
    
    public void setName(String name) {
     try{
     if (name==null){
     throw new IllegalArgumentException("Name connot be null");    
     }
     this.name=name;
     }catch(IllegalArgumentException e){
     System.out.println("Error setting name : " + e.getMessage());
     }
    }
    
     /*
     * Gets the email of the user.
     *
     * @return the email of the user
     */
    
    public String getEmail() {
        return email;
    }

     /*
     * Sets the email of the user
     * @param email the email to set
     * @throws IllegalArgumentException if the email is null 
     */
    
    public void setEmail(String email) {
     try{
     if (email==null){
     throw new IllegalArgumentException(" Email connot be null ");    
     }
     this.email=email;
     }catch(IllegalArgumentException e){
     System.out.println("Error setting email : " + e.getMessage());
     }
    }

    /*
     * Gets the password of the user.
     *
     * @return the password of the user
     */
    
    public String getPassword() {
        return password;
    }

    /*
     * Sets the password of the user.
     * @param password the password to set
     *@throws IllegalArgumentException if the password is null 
     */
    
    public void setPassword(String password) {
        try{
     if (password==null){
     throw new IllegalArgumentException(" password connot be null ");    
     }
     this.password=password;
     }catch(IllegalArgumentException e){
     System.out.println("Error setting password : " + e.getMessage());
     }
    }

    // Abstract Methods

    /*
     * Abstract method to display user information.
     * This method must be implemented by subclasses.
     */
    
    public abstract void displayInfo();
    

   // Interface Methods

    /*
     * Interface method to display user login and logout.
     * This method can be implemented by abstract class or subclasses.
     */
    
    public void login(){
    System.out.println("user logged in.");
    }
    
     /*
     * Interface method to display user login and logout.
     * This method can be implemented by abstract class or subclasses.
     */

    public void logout(){
    System.out.println("user logged out.");   
    } 
   
    
     // Override Methods

    /*
     * Returns a string representation of the user.
     *
     * @return a string representation of the user
     */

    @Override
    public String toString() {
        return  " name = " + name + " , email = " + email + " , password = " + password;
    }

     /*
     * Checks if this user is equal to another object.
     *
     * @param obj the object to compare
     * @return true if the objects are equal, false otherwise
     */
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null|| !(obj instanceof User)){
         return false;    
        } 
        User user = ((User)obj);       
        return name.equals(user.name) && email.equals(user.email) && password.equals(user.password);
        }
}
