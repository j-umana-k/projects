package elearningplatform;
/** The UserInterface class represents user login and logout functionalities.
 * This interface defines methods that can be implemented by abstract classes or subclasses
 * to manage user authentication processes.
 * 
 * name : Jumana khalid Alsaedi
 * ID : 445007196
 * group : 2
 * @author Jumana khalid Alsaedi
 */


public interface UserInterface { 
  
  // Interface Methods

     /**
     * Method to display user login.
     * This method should be implemented by classes that handle user authentication
     * to define the behavior when a user logs in.
     */
    
public void login();

    /**
     * Method to display user logout.
     * This method should be implemented by classes that handle user authentication
     * to define the behavior when a user logs out.
     */

public void logout(); 
      
}
