package elearningplatform;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
/**
 * ELearningPlatform.java
 * 
 * This class serves as the entry point for an e-learning platform application. 
 * It initializes and manages key components such as users, professors, students, 
 * and courses using ArrayList collections. The program demonstrates how to 
 * manage the relationships between these entities by associating professors with courses.
 *  
  * Student Name: Lames Alrebeay
  * ID: 445004550
  * Group#: 2
  */
public class ELearningPlatform {

    public static void main(String[] args) {
        // Initialize collections to store users, professors, courses, and students
        ArrayList<User> Users=new ArrayList<User>();
        ArrayList<Professor> Professors=new ArrayList<Professor>();
        ArrayList<Course> courses=new ArrayList<Course>();
        ArrayList<Student> students=new ArrayList<Student>();
        //Create professors
        Professor NoProf=new Professor(0,"NoProf",null,null);
        Professor ProfSalma=new Professor(18976, "Salma","Salma@gmail.com","S4563");
        Professor ProfYusuf=new Professor(18777, "Yusuf","Yusuf34@gmail.com","Prof123");
        //Create courses
        Course Maths1=new Course(5647, "Maths1", ProfSalma, "2 months");
        Course English=new Course(1234, "English", ProfYusuf, "2 months");
        Course Programming=new Course(3454, "Programming", ProfYusuf, "4 months");
        Course Programming2=new Course(7765, "Programming2",NoProf ,"4 months");
        Course Arabic=new Course(7769, "Arabic",NoProf,"2 months");
        //Add professors to list of Professors and add courses.
        ProfSalma.addCourse(Maths1);
        ProfYusuf.addCourse(English);
        Professors.add(ProfYusuf);
        Professors.add(ProfSalma);
        Users.addAll(Professors);
        //Add courses to list of courses
        courses.add(English);
        courses.add(Maths1);
        courses.add(Programming);
        courses.add(Arabic);
        courses.add(Programming2);
        //Create Students and add them to list of students
        Student student1=new Student("Lames", "Lames@gmail.com", "Password1", 44500);
        Student student2=new Student("Abrar", "Abrar@gmail.com", "Password45", 44523);
        Student student3=new Student("Ryan", "Ryan@gmail.com", "RyanPassword", 44598);
        Student student4=new Student("Alex", "Alex@gmail.com", "PasswordAlex", 44630);
        Student student5=new Student("Sarah", "Sarah@gmail.com", "SarahPassword", 44411);
        students.add(student1);
        students.add(student2);
        students.add(student3);
        students.add(student4);
        students.add(student5);
        Users.addAll(students);
        
        Scanner input = new Scanner(System.in);
        int choice;
        /**
        * Displays the menu to user and asks for type of user.
        * Displays specific menu for each type.
        */
        do {
            System.out.println("What user are you?\nEnter: \n1 for Student\n2 for Professor\n3 for Admin\n4 to exit");
            choice=input.nextInt();
            
            switch(choice){
                //Student menu
                case 1: //Logs in student
                    System.out.print("To log in enter your name: ");
                    String name=input.next();
                    System.out.print("Enter your email: ");
                    String email=input.next();
                    System.out.print("Enter your password: ");
                    String pass=input.next();
                    System.out.print("Enter your ID: ");
                    long ID=input.nextLong();
                    students.add(new Student(name,email,pass,ID));
                    new Student(name,email,pass,ID).login();
                    int option=0;
                    do{//Displays student menu
                        System.out.println("Student menu:\n1. Enroll course\n2. Drop Course\n3. Display personal info\n4. Log Out"); 
                        option=input.nextInt();
                        if(option==1){ //Enrolls into course
                            System.out.println("Available courses to enroll in:");
                             for(int i =0;i<courses.size(); i++){
                                 System.out.println(courses.get(i).toString());
                             }
                             System.out.println("Enter course ID :");
                             int courseID=input.nextInt();
                             for(int i =0;i<courses.size(); i++){
                                 if ((courses.get(i).getCourseId())==courseID){
                                     for(int j =0;j<students.size(); j++){
                                         if ((students.get(j).getId())==ID){
                                             students.get(j).enrollCourse(courses.get(i));
                                             courses.get(i).addStudent(students.get(j));
                                         }
                                     }
                                 }       
                             }
                        }
                        else if(option==2){//Drops course
                            System.out.println("Enrolled Courses:");
                            for(int i =0;i<students.size(); i++){
                                if ((students.get(i).getId())==ID){
                                    System.out.println(students.get(i).getEnrolledCourses());
                                }}
                             System.out.println("Enter course ID of course to be dropped:");
                             int courseID=input.nextInt();
                             for(int i =0;i<courses.size(); i++){
                                 if ((courses.get(i).getCourseId())==courseID){
                                     for(int j =0;j<students.size(); j++){
                                         if ((students.get(j).getId())==ID){
                                             students.get(j).dropCourse(courses.get(i));
                                             courses.get(i).removeStudent(students.get(j));
                                         }
                                     }
                                 }       
                             }
                        }
                        else if(option==3){//Displays personal information
                            System.out.println("Student Information: ");
                            for(int i =0;i<students.size(); i++){
                                if ((students.get(i).getId())==ID){
                                    (students.get(i)).displayInfo();
                                }}
                        }
                        else//Logs out
                            new Student(name,email,pass,ID).logout();
                    } while(option!=4);
                    break;
                //Professor menu
                case 2://Creates professor and logs in
                    System.out.print("To log in enter your name: ");
                    name=input.next();
                    System.out.print("Enter your email: ");
                    email=input.next();
                    System.out.print("Enter your password: ");
                    pass=input.next();
                    System.out.print("Enter your ID: ");
                    long PID=input.nextLong();
                    Professors.add(new Professor(PID,name,email,pass));
                    new Professor(PID,name,email,pass).login();
                    option=0;
                    do{//Displays menu
                        System.out.println("Professor menu:\n1. Add course\n2. Remove Course\n3. Office hours\n4. Personal Information\n5. Courses\n6. Log Out"); 
                        option=input.nextInt();
                        if(option==1){ //Adds course
                            System.out.println("Available courses to add:");
                            ArrayList<Course> available=new ArrayList<Course>();
                             for(int i =0;i<courses.size(); i++){
                                 if ((courses.get(i).getProfessor())==NoProf){
                                 available.add(courses.get(i));
                                 } }
                             if(available.isEmpty()){
                                 System.out.println("No available courses");}
                             else{
                                 for(int i =0;i<available.size(); i++){
                                 System.out.println(available.get(i).toString());}
                             System.out.println("Enter course ID of course to add:");
                             int courseID=input.nextInt();
                             for(int i =0;i<available.size(); i++){
                                 if ((available.get(i).getCourseId())==courseID){
                                     for(int j =0;j<Professors.size(); j++){
                                         if ((Professors.get(j).getID())==PID){
                                             Professors.get(j).addCourse(available.get(i));
                                             available.get(i).setProfessor(Professors.get(j));
                                             System.out.println("Course added.");
                                         }
                                     }
                                 }       
                             }
                        }}
                        else if(option==2){//Removes course
                            System.out.println("Enrolled Courses:");
                            for(int i =0;i<Professors.size(); i++){
                                if ((Professors.get(i).getID())==PID){
                                    System.out.println(Professors.get(i).getTaughtCourses());
                                }}
                             System.out.println("Enter course ID of course to be removed:");
                             int courseID=input.nextInt();
                             for(int i =0;i<courses.size(); i++){
                                 if ((courses.get(i).getCourseId())==courseID){
                                     for(int j =0;j<Professors.size(); j++){
                                         if ((Professors.get(j).getID())==PID){
                                             Professors.get(j).removeCourse(courses.get(i));
                                             courses.get(i).setProfessor(NoProf);
                                         }
                                     }
                                 }       
                             }
                        }
                        else if(option==3){//Displays office hours and gives options for setting and changing
                            System.out.println("Office hours:");
                            for(int i =0;i<Professors.size(); i++){
                                if ((Professors.get(i).getID())==PID){
                                    if(Professors.get(i).getOfficeHours().isEmpty()){
                                        System.out.println("You have no current office hours.\nWould you like to set office hours?\nEnter 1 for yes, 2 for no. ");
                                        int set=input.nextInt();
                                        if (set==1){
                                            System.out.println("Enter when you want to schedule office hours:\nEnter Day:");
                                            String officeHour=input.next();
                                            System.out.println("Enter time:");
                                            officeHour+=":"+input.next();
                                            Professors.get(i).scheduleOfficeHour(officeHour);
                                        }
                                        else break;
                                    }
                                    else {System.out.println(Professors.get(i).getOfficeHours());
                                    System.out.println("Would you like to change office hours? Enter 1 for yes, 2 for no ");
                                    int set=input.nextInt();
                                    if (set==1){
                                        Professors.get(i).getOfficeHours().clear();
                                            System.out.println("Enter when you want to schedule office hours:\nEnter Day:");
                                            String officeHour=input.next();
                                            System.out.println("Enter time:");
                                            officeHour+=":"+input.next();
                                            Professors.get(i).scheduleOfficeHour(officeHour);
                                        }
                                        else break;
                                    }
                                }}
                        }
                        else if(option==4){//Displays personal information
                            System.out.println("Personal information: ");
                            for(int i =0;i<Professors.size(); i++){
                                if ((Professors.get(i).getID())==PID){
                                    (Professors.get(i)).displayInfo();
                                }}
                        }
                        else if(option==5){//Displays courses.
                           System.out.println("Enrolled Courses:");
                            for(int i =0;i<Professors.size(); i++){
                                if ((Professors.get(i).getID())==PID){
                                    System.out.println(Professors.get(i).getTaughtCourses());
                                }} 
                        }
                        else
                            new Professor(PID,name,email,pass).logout();
                    } while(option!=6);
                    break;
                case 3://Admin menu
                    //Logs in admin
                    System.out.print("To log in enter your name: ");
                    name=input.next();
                    System.out.print("Enter your email: ");
                    email=input.next();
                    System.out.print("Enter your password: ");
                    pass=input.next();
                    System.out.print("Enter your ID: ");
                    long AID=input.nextLong();
                    new Admin(name,email,pass,AID).login();
                    Users.add(new Admin(name,email,pass,AID));
                    ((Admin)Users.getLast()).setTaughtCourses(courses);
                    option=0;
                    do{//Displays menu
                        System.out.println("Admin menu:\n1. Add course\n2. Get Courses\n3. Print Professors\n4. Print Student information\n5. Add new user\n6. Log Out"); 
                        option=input.nextInt();
                        if(option==1){//Adds courses
                            System.out.println("Enter Course name:");
                            String CName=input.next();
                            System.out.println("Enter Course ID:");
                            int Cid=input.nextInt();
                            System.out.println("Enter Course Professor's name:");
                            String PName=input.next();
                            System.out.println("Enter number of months of duration:");
                            String months=input.next()+" months";
                            for(int i =0;i<Professors.size(); i++){
                                if ((Professors.get(i).getName()).equals(PName)){
                                    courses.add(new Course(Cid,CName,Professors.get(i),months));
                                    Professors.get(i).addCourse(courses.getLast());
                                    ((Admin)Users.getLast()).setTaughtCourses(courses);
                                    System.out.println("Course added.");
                                }} 
                        }
                        else if(option==2){//Prints courses
                            System.out.println(((Admin)Users.getLast()).getTaughtCourses());}
                        else if(option==3){//Prints professors
                            for(int i =0;i<Professors.size(); i++){
                                System.out.println(Professors.get(i).toString());
                            }
                        }
                        else if(option==4){//Prints students
                            for(int i =0;i<students.size(); i++){
                                students.get(i).displayInfo();
                            }
                        }
                        else if(option==5){//Creates and adds new user information 
                            ((Admin)Users.getLast()).manageUsers();
                            System.out.println("User added.");
                        }//Logs out
                        else new Admin(name,email,pass,AID).logout();
                    }while(option!=6);
                    break;
            }
        }
        while(choice!=4);
    }
    
}
