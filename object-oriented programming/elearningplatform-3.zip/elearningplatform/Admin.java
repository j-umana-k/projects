package elearningplatform;

import java.util.ArrayList;
import java.util.Scanner;
/**
 * This class is designed to facilitate the management
 * of classes within our system.
 * As an admin, you can add and remove any classes you want.
 */
/**
 *Name: Alshyhanh Algithami
 *ID:445005055
 *Group:2
 */
public class Admin extends User {
    
    //A unique identifier for the admin.
    private long ID;
    
    //An array list to store the courses managed by the admin.
    private ArrayList<Course> taughtCourses =new ArrayList<>();
    
    //A setter and gette methods for the private attributes:
    /**
     * Sets the admin's unique identifier.
     * @param ID the unique identifier to set
     */

    public void setID(long ID) {this.ID = ID;}
    /**
     * Retrieves the admin's unique identifier.
     * @return the unique identifier of the admin
     */
    public long getID() {return ID;}
    
    /**
     * Sets the list of courses taught by the admin.
     * @param taughtCourses the list of courses to set
     */
    
    public void setTaughtCourses(ArrayList<Course> taughtCourses) {this.taughtCourses = taughtCourses;}
    /**
     * Retrieves the list of courses taught by the admin.
     * @return the list of courses managed by the admin
     */
    public ArrayList<Course> getTaughtCourses() {return taughtCourses;}
    
    //Constructor without any arguments.
    public Admin(){this.ID=0; this.taughtCourses=null;}
    
    /**
     * Constructor with arguments.
     * @param name     the name of the admin
     * @param email    the email of the admin
     * @param password the password of the admin
     * @param ID       the unique identifier for the admin
     */
    public Admin(String name, String email, String password,long ID){
        super(name,email,password);
        this.ID=ID;
    }
    
    /**
     * A method to remove a course from the list.
     * @param course the course to add
     */
    public void addCourse(Course course) {
        taughtCourses.add(course);
    }
    
    /**
     * Method to remove a course.
     * @param course the course to remove
     */
    public void removeCourse(Course course) {
        taughtCourses.remove(course);
    }

    //Overriding the displayInfo method from the Superclass.
    @Override
    public void displayInfo() {
        System.out.println("Admin ID: "+ID);
        System.out.println("Courses: ");
        if (taughtCourses.isEmpty()) {
        System.out.println("No courses found.");
    }else{   
        for (Course course : taughtCourses) {
            System.out.print(course + " ");}
            System.out.println();}
    }
    
    /**
     * Returns a string representation of the admin, ID and courses.
     * @return a string representation of the admin
     */
    @Override
    public String toString() {
        return "ID: " + ID + "Courses: " + taughtCourses;
    }
    
    /**
     * Checks if this admin is equal to another object.
     * @param o the object to compare
     * @return true if the objects are equal, false if they are not equal.
     */
    @Override
    public boolean equals(Object o){
        if (this==o) return true; 
       if (o instanceof Admin){
       Admin other=(Admin)o;
       return ID==other.ID;
       }
       return false;
    }

    //A method to add a new user.
    public void manageUsers(){
      Scanner input = new Scanner(System.in);
      System.out.println("Enter a new User information.");
      
        System.out.println("Enter user type: ");
        String userType = input.nextLine();
        
        System.out.println("Enter user name: ");
        String userName = input.nextLine();
        
        System.out.println("Enter user ID: ");
        long userID = input.nextLong();
        
        System.out.println("Enter user email: ");
        String userEmail = input.next();
        
        System.out.println("Enter user password: ");
        String userPassword = input.next();
        
        if (userType.equalsIgnoreCase("Student")) {
            Student newUser = new Student(userName,userEmail,userPassword,userID);
       } else if (userType.equalsIgnoreCase("Professor")) {
            Professor newUser = new Professor(userID,userName,userEmail,userPassword);
            }
    else {
            System.out.println("Invalid input");
            }
        }
    
    @Override
    public void login() {
        System.out.println("Admin logged in.");
    }

    @Override
    public void logout() {
        System.out.println("Admin logged out.");
    }
        
    }
    
    
    

