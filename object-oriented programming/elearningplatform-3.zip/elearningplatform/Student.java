package elearningplatform;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*
 * The Student class represents a student with an ID and enrolled courses.
 * It extends the User class and provides methods to manage course enrollment and display student information.
 */
public class Student extends User {
    
    private long id; // Unique identifier for the student
    private List<Course> enrolledCourses; // List of courses the student is enrolled in   

    // Default constructor
    public Student() {
        super(); // Call to the User default constructor
        this.id = 0;
        this.enrolledCourses = new ArrayList<>();
        System.out.print("Error: No information has been entered, default values have been set");
    }

    // Parameterized constructor
    public Student(String name, String email, String password, long id) {
        super(name, email, password);
        this.id = id;
        this.enrolledCourses = new ArrayList<>();
    }

    // Method to display student information
    @Override
    public void displayInfo() {
        System.out.println("Student ID: " + id);
        System.out.println("Name: " + getName());
        System.out.println("Email: " + getEmail());
        System.out.println("Enrolled Courses: " + enrolledCourses);
    }

    // Enrolls the student in a course
    public void enrollCourse(Course course) {
        if (!enrolledCourses.contains(course)) {
            enrolledCourses.add(course);
            System.out.println("Enrolled in: " + course.getCourseName());
        } else {
            System.out.println("Already enrolled in: " + course.getCourseName());
        }
    }

    // Drops the student from a course
    public void dropCourse(Course course) {
        if (enrolledCourses.remove(course)) {
            System.out.println("Dropped from: " + course.getCourseName());
        } else {
            System.out.println("Not enrolled in: " + course.getCourseName());
        }
    }

    // Returns a string representation of the student
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + getName() + ", Email: " + getEmail() + ", Courses: " + enrolledCourses;
    }

    // Compares this student to another object
    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Student)) {
            return false;
        }
        Student student = (Student) obj;
        return super.equals(student) && id==(student.id);
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(List<Course> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }

    // Additional Methods
    public void viewGrades() {
        // Implementation for viewing grades
        System.out.println("Viewing grades for student ID: " + id);
    }

    public void submitAssignment() {
        // Implementation for submitting an assignment
        System.out.println("Submitting assignment for student ID: " + id);
    }

    public void participateInDiscussion() {
        // Implementation for participating in a discussion
        System.out.println("Participating in discussion for student ID: " + id);
    }
}