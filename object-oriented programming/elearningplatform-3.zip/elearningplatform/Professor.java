package elearningplatform;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author raneem
 */

/**
 * The Professor class represents a professor in the university.
 * It extends the User class and includes additional attributes and methods
 * specific to a professor.
 */
public class Professor extends User {
        private long ID;
        private List<Course> taughtCourses;
        private List<String> officeHours;

    /**
     * Default constructor.
     * Initializes the taughtCourses and officeHours lists.
     */
    public Professor() {
        super();
        this.taughtCourses = new ArrayList<>();
        this.officeHours = new ArrayList<>();
    }

    /**
     * Parameterized constructor.
     * @param name The name of the professor.
     * @param email The email of the professor.
     * @param password The password of the professor.
     * @param ID The id of the professor.
     */

    public Professor(long ID, String name, String email, String password) {
        super(name, email, password);
        this.ID=ID;
        this.taughtCourses = new ArrayList<>();
        this.officeHours = new ArrayList<>();
    }
 /*Setters and Getters
      *
     *Gets the id of the user
     *@return the id of the user
    */
    
    public long getID() {
        return ID;
    }
 /*
     * Sets the name of the user
     * @param name the name to set 
    */
    public void setID(long ID) {
        this.ID = ID;
    }
    
    /**
     * Gets the list of courses taught by the professor.
     * @return The list of taught courses.
     */
    public List<Course> getTaughtCourses() {
        return taughtCourses;
    }

    /**
     * Sets the list of courses taught by the professor.
     * @param taughtCourses The list of taught courses.
     */
    public void setTaughtCourses(List<Course> taughtCourses) {
        this.taughtCourses = taughtCourses;
    }

    /**
     * Gets the list of office hours scheduled by the professor.
     * @return The list of office hours.
     */
    public List<String> getOfficeHours() {
        return officeHours;
    }

    /**
     * Sets the list of office hours scheduled by the professor.
     * @param officeHours The list of office hours.
     */
    public void setOfficeHours(List<String> officeHours) {
        this.officeHours = officeHours;
    }

    /**
     * Displays the professor's information, including ID, name, taught courses, and office hours.
     */
        @Override
    public void displayInfo() {
        System.out.println("Professor ID: " + getID());
        System.out.println("Professor Name: " + getName());
        System.out.println("Professor Email: " + getEmail());
        System.out.println("Professor Password: " + getPassword());
        System.out.println("Taught Courses: " + taughtCourses);
        System.out.println("Office Hours: " + officeHours);
        
    }
     
    /**
     * Adds a course to the professor's list of taught courses.
     * @param course The course to be added.
     */
    public void addCourse(Course course) {
        taughtCourses.add(course);
    }

    /**
     * Removes a course from the professor's list of taught courses.
     * @param course The course to be removed.
     */
    public void removeCourse(Course course) {
        taughtCourses.remove(course);
    }

    /**
     * Returns a string representation of the professor.
     * @return A string representation of the professor.
     */
   @Override
   public String toString() {
        return "Professor{" +
               "id='" + getID() + '\'' +
                ", name='" + getName() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", password='" + getPassword() + '\'' +
                ", taughtCourses=" + taughtCourses +
                ", officeHours=" + officeHours +
               '}';
  }

    /**
     * Compares this professor to another object.
     * @param obj The object to compare to.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        if (!super.equals(obj)) return false;
        Professor professor = (Professor) obj;
        return taughtCourses.equals(professor.taughtCourses) && officeHours.equals(professor.officeHours);
    }

    /**
     * Schedules an office hour.
     * @param dateTime The date and time of the office hour.
     */
    public void scheduleOfficeHour(String dateTime) {
        officeHours.add(dateTime);
        System.out.println("Office hour scheduled on: " + dateTime);
    }

}
